# UserChangePasswordRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NewPassword** | **string** | New password value. | [default to null]
**OldPassword** | **string** | Old password should be passed as a validation parameter. | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

