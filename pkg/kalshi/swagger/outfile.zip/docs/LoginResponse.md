# LoginResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AccessLevel** | **string** | Access level, to limit the access that applicants have | [default to null]
**Token** | **string** | Access token for an member role session in the api | [default to null]
**UserId** | **string** | Your user_id, this will be required in all requests under the /users prefix | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

