# UserBatchOrdersCancelResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Orders** | [**[]UserBatchOrdersCancelSingleOrderResponse**](UserBatchOrdersCancelSingleOrderResponse.md) | An array of responses corresponding to the orders in the request. | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

