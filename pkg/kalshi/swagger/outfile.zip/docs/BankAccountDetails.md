# BankAccountDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BankId** | **string** |  | [default to null]
**Mask** | **string** |  | [default to null]
**Name** | **string** |  | [default to null]
**PlaidItemNeedsRelink** | **bool** |  | [default to null]
**RoutingNumber** | **string** |  | [optional] [default to null]
**Subtype** | **string** |  | [default to null]
**Type_** | **string** |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

