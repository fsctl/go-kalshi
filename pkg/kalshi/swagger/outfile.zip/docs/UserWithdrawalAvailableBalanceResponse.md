# UserWithdrawalAvailableBalanceResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AvailableBalanceCents** | **int64** |  | [default to null]
**WithdrawalFeeCents** | **int64** |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

