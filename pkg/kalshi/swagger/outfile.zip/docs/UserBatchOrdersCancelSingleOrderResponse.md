# UserBatchOrdersCancelSingleOrderResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Error_** | [***JsonError**](JSONError.md) |  | [optional] [default to null]
**Id** | **string** | ID of the order | [default to null]
**Order** | [***Order**](Order.md) |  | [optional] [default to null]
**ReducedBy** | **int32** | Result of the decrease operation | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

