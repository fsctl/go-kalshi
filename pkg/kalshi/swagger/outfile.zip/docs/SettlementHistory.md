# SettlementHistory

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DeterminedTime** | [**time.Time**](time.Time.md) |  | [optional] [default to null]
**MarketId** | **string** |  | [optional] [default to null]
**MarketResult** | **string** |  | [optional] [default to null]
**MarketTitle** | **string** |  | [optional] [default to null]
**NoCount** | **int64** |  | [optional] [default to null]
**NoTotalCost** | **int64** |  | [optional] [default to null]
**Profit** | **int64** |  | [optional] [default to null]
**SettledTime** | [**time.Time**](time.Time.md) |  | [optional] [default to null]
**YesCount** | **int64** |  | [optional] [default to null]
**YesTotalCost** | **int64** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

