# UserDepositResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Deposit** | [***Deposit**](Deposit.md) |  | [optional] [default to null]
**DepositId** | **string** | Id for the deposit that was created. | [default to null]
**EstimatedAchTimeDays** | **int32** | The estimated number of days we believe the ach transfer will take | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

