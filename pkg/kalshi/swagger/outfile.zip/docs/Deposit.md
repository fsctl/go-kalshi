# Deposit

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AmountCents** | **int64** |  | [optional] [default to null]
**BankId** | **string** |  | [optional] [default to null]
**CreatedTs** | [**time.Time**](time.Time.md) |  | [optional] [default to null]
**DepositType** | **string** |  | [optional] [default to null]
**Id** | **string** |  | [optional] [default to null]
**ImmediateAmount** | **int64** |  | [optional] [default to null]
**ImmediateStatus** | **string** |  | [optional] [default to null]
**ReturnCode** | **string** |  | [optional] [default to null]
**ReturnReason** | **string** |  | [optional] [default to null]
**Status** | **string** |  | [optional] [default to null]
**UserId** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

