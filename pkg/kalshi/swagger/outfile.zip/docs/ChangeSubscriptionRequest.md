# ChangeSubscriptionRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PushPreferences** | **bool** |  | [optional] [default to null]
**SubscriptionLevel** | **string** | Specifies the subscription level for email notifications its values can be: \&quot;none\&quot;, \&quot;basic\&quot; or \&quot;all\&quot; | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

