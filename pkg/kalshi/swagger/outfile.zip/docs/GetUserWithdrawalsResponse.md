# GetUserWithdrawalsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Withdrawals** | [**[]Withdrawal**](Withdrawal.md) | List of previous withdrawals for the user | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

