# RangedMarket

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** |  | [optional] [default to null]
**MiniTitle** | **string** |  | [optional] [default to null]
**MutuallyExclusiveSide** | **string** |  | [optional] [default to null]
**Ticker** | **string** |  | [optional] [default to null]
**Title** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

