# UserBatchOrdersCreateRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Orders** | [**[]UserOrderCreateRequest**](UserOrderCreateRequest.md) | An array of individual orders to place | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

