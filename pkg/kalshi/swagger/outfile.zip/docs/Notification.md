# Notification

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Content** | [**map[string]interface{}**](interface{}.md) |  | [optional] [default to null]
**CreatedTs** | [**time.Time**](time.Time.md) |  | [optional] [default to null]
**Id** | **string** |  | [optional] [default to null]
**IsDelivered** | **bool** |  | [optional] [default to null]
**IsRead** | **bool** |  | [optional] [default to null]
**Link** | **string** |  | [optional] [default to null]
**Type_** | **string** |  | [optional] [default to null]
**UserId** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

