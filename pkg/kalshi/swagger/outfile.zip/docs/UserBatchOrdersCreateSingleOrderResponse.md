# UserBatchOrdersCreateSingleOrderResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Error_** | [***JsonError**](JSONError.md) |  | [optional] [default to null]
**Order** | [***Order**](Order.md) |  | [optional] [default to null]
**Status** | **string** | Status of the order submit operation | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

