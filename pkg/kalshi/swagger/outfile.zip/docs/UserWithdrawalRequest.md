# UserWithdrawalRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AmountCents** | **int64** |  | [default to null]
**BankId** | **string** |  | [default to null]
**FeeCents** | **int64** |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

