# PeopleReferred

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Email** | **string** |  | [optional] [default to null]
**ReferralId** | **string** |  | [optional] [default to null]
**StageInFunnel** | **string** |  | [optional] [default to null]
**TimeOfReferralExpiration** | [**time.Time**](time.Time.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

