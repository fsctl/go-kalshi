# MarketHistoryCandleStickInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EndTs** | **int64** |  | [optional] [default to null]
**OpenInterest** | **int64** |  | [optional] [default to null]
**Price** | [***Olhcm**](OLHCM.md) |  | [optional] [default to null]
**StartTs** | **int64** |  | [optional] [default to null]
**Volume** | **int64** |  | [optional] [default to null]
**YesAsk** | [***Olhcm**](OLHCM.md) |  | [optional] [default to null]
**YesBid** | [***Olhcm**](OLHCM.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

