# Olhcm

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Close** | **int64** |  | [optional] [default to null]
**High** | **int64** |  | [optional] [default to null]
**Low** | **int64** |  | [optional] [default to null]
**Mean** | **int64** |  | [optional] [default to null]
**Open** | **int64** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

