# ConfirmPasswordResetRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Password** | **string** | The new password. | [default to null]
**UserId** | **string** | UserUUID for your user. You can get this from the password reset link query parameter. | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

