# TradeHistory

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Amount** | **int64** |  | [optional] [default to null]
**CreatedAt** | [**time.Time**](time.Time.md) |  | [optional] [default to null]
**Fee** | **int64** |  | [optional] [default to null]
**IsYes** | **bool** |  | [optional] [default to null]
**MarketId** | **string** |  | [optional] [default to null]
**MarketTitle** | **string** |  | [optional] [default to null]
**Price** | **int64** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

