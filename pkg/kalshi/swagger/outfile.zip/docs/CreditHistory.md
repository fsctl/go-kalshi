# CreditHistory

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AmountCents** | **int64** |  | [optional] [default to null]
**CreatedAt** | [**time.Time**](time.Time.md) |  | [optional] [default to null]
**Reason** | **string** |  | [optional] [default to null]
**Status** | **string** |  | [optional] [default to null]
**Type_** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

