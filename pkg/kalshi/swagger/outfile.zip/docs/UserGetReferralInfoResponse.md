# UserGetReferralInfoResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EligibleToRefer** | **bool** |  | [optional] [default to null]
**NumContractsTraded** | **int64** |  | [optional] [default to null]
**PeopleReferred** | [***[]PeopleReferred**](array.md) |  | [optional] [default to null]
**ReferralCode** | **string** |  | [optional] [default to null]
**ReferralId** | **string** |  | [optional] [default to null]
**ReferralMoneyRewarded** | **int64** |  | [optional] [default to null]
**StageInFunnel** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

