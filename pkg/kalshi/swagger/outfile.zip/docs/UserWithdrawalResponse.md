# UserWithdrawalResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Withdrawal** | [***Withdrawal**](Withdrawal.md) |  | [optional] [default to null]
**WithdrawalId** | **string** | Id for the withdrawal that was created. | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

