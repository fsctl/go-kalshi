# Series

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FirstOpenDate** | [**time.Time**](time.Time.md) |  | [optional] [default to null]
**Frequency** | **string** |  | [optional] [default to null]
**Ticker** | **string** |  | [optional] [default to null]
**Title** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

