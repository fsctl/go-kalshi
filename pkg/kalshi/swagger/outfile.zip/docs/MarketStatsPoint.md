# MarketStatsPoint

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DollarOpenInterest** | **int64** |  | [optional] [default to null]
**DollarVolume** | **int64** |  | [optional] [default to null]
**OpenInterest** | **int64** |  | [optional] [default to null]
**Price** | **int64** |  | [optional] [default to null]
**Ts** | **int64** |  | [optional] [default to null]
**Volume** | **int64** |  | [optional] [default to null]
**YesAsk** | **int64** |  | [optional] [default to null]
**YesBid** | **int64** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

